// roles guard removed - not used in slim auth service
export {};
