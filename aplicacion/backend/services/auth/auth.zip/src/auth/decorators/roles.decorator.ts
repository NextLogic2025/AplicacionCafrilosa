// roles decorator removed - not used in slim auth service
export {};
